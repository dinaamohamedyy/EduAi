#!/usr/bin/env bash
#
# One-shot bootstrap for the Scholaris learning platform.
#
# Installs WordPress, the recommended plugin stack, activates the custom theme
# and plugins, and creates the pages the site expects (Library, My Progress,
# Study Assistant) with the right shortcodes and menu.
#
# Run it against the Docker stack:
#     docker compose up -d
#     docker compose run --rm --profile tools cli bash /scripts/setup.sh
#
# Or on a live host that has wp-cli available:
#     cd /path/to/wordpress && bash /path/to/scripts/setup.sh
#
set -euo pipefail

WP="wp --allow-root --path=${WP_PATH:-/var/www/html}"

SITE_URL="${SITE_URL:-http://localhost:8080}"
SITE_TITLE="${SITE_TITLE:-Scholaris}"
ADMIN_USER="${ADMIN_USER:-admin}"
ADMIN_PASSWORD="${ADMIN_PASSWORD:-change-me-now}"
ADMIN_EMAIL="${ADMIN_EMAIL:-you@example.com}"

say() { printf '\n\033[1;36m▸ %s\033[0m\n' "$1"; }
ok()  { printf '  \033[0;32m✓\033[0m %s\n' "$1"; }

# ---------------------------------------------------------------- core -----
say "Checking WordPress core"
if ! $WP core is-installed 2>/dev/null; then
	$WP core install \
		--url="$SITE_URL" \
		--title="$SITE_TITLE" \
		--admin_user="$ADMIN_USER" \
		--admin_password="$ADMIN_PASSWORD" \
		--admin_email="$ADMIN_EMAIL" \
		--skip-email
	ok "WordPress installed"
else
	ok "WordPress already installed"
fi

# ------------------------------------------------------------- settings ----
say "Applying site settings"
$WP option update blogdescription "Study material, quizzes and an AI study assistant"
$WP option update permalink_structure '/%postname%/'
$WP option update timezone_string 'Africa/Cairo'
$WP option update users_can_register 1
$WP option update default_role 'subscriber'
$WP rewrite flush --hard
ok "Settings applied"

# -------------------------------------------------------------- plugins ----
say "Installing the plugin stack"

# Core LMS + quizzes
PLUGINS=(
	tutor                       # Tutor LMS — courses, lessons, quizzes, attempt history
	classic-editor              # Predictable editing for course authors (optional)
	wordpress-seo               # Yoast SEO
	wordfence                   # Firewall + login hardening
	updraftplus                 # Scheduled backups
	wp-super-cache              # Page caching
	webp-express                # Image optimisation
	wps-hide-login              # Move wp-login.php away from the default URL
	user-role-editor            # Fine-grained student/instructor capabilities
	redirection                 # Manage redirects
	loco-translate              # Edit theme/plugin strings without touching code
)

for plugin in "${PLUGINS[@]}"; do
	if $WP plugin is-installed "$plugin" 2>/dev/null; then
		ok "$plugin already installed"
	else
		$WP plugin install "$plugin" --activate && ok "$plugin installed"
	fi
done

# Activate ours (they are bind-mounted, not downloaded)
$WP plugin activate scholaris-library eduai-assistant 2>/dev/null || true
$WP plugin activate tutor 2>/dev/null || true
ok "Custom plugins activated"

# ---------------------------------------------------------------- theme ----
say "Activating the Scholaris theme"
$WP theme activate scholaris
ok "Theme active"

# ---------------------------------------------------------------- pages ----
say "Creating pages"

make_page() {
	local title="$1" slug="$2" content="$3"

	if $WP post list --post_type=page --name="$slug" --format=count | grep -q '^0$'; then
		$WP post create \
			--post_type=page \
			--post_title="$title" \
			--post_name="$slug" \
			--post_status=publish \
			--post_content="$content" >/dev/null
		ok "created /$slug/"
	else
		ok "/$slug/ already exists"
	fi
}

make_page "Home" "home" "Welcome to $SITE_TITLE."
make_page "Library" "library" "[scholaris_library per_page=\"12\" filters=\"yes\"]"
make_page "My Progress" "dashboard" "[scholaris_dashboard]"
make_page "Study Assistant" "assistant" "[eduai_panel height=\"600\"]"
make_page "Summarise a Lecture" "summarise" "[eduai_summarizer]"
make_page "Privacy Policy" "privacy" "How student data and AI conversations are handled."

# Static front page
HOME_ID=$($WP post list --post_type=page --name=home --field=ID | head -1)
if [ -n "$HOME_ID" ]; then
	$WP option update show_on_front page
	$WP option update page_on_front "$HOME_ID"
	ok "Front page set"
fi

# ----------------------------------------------------------------- menu ----
say "Building the primary menu"

if ! $WP menu list --format=csv | grep -q '^.*,Primary,'; then
	$WP menu create "Primary" >/dev/null || true
fi

add_menu_item() {
	local slug="$1"
	local id
	id=$($WP post list --post_type=page --name="$slug" --field=ID | head -1)
	[ -n "$id" ] && $WP menu item add-post Primary "$id" >/dev/null 2>&1 || true
}

for slug in home library dashboard assistant; do
	add_menu_item "$slug"
done

$WP menu location assign Primary primary >/dev/null 2>&1 || true
ok "Menu assigned"

# ------------------------------------------------------------ taxonomies ---
say "Seeding subjects"
for subject in "Mathematics" "Physics" "Computer Science" "Biology" "Chemistry"; do
	$WP term create material_subject "$subject" >/dev/null 2>&1 || true
done
ok "Subjects created"

# ----------------------------------------------------------------- roles ---
say "Creating the student role"
$WP role create student "Student" --clone=subscriber >/dev/null 2>&1 || true
$WP cap add student read >/dev/null 2>&1 || true
ok "Student role ready"

# --------------------------------------------------------------- wrap up ---
say "Done"
cat <<EOF

  Site:      $SITE_URL
  Admin:     $SITE_URL/wp-admin  ($ADMIN_USER)

  Next steps
  ----------
  1. Settings → EduAI Assistant: paste your Claude API key
     (or define EDUAI_ANTHROPIC_API_KEY in wp-config.php — preferred).
  2. Library → Add study material: upload a lecture PDF.
  3. Settings → EduAI Assistant → "Rebuild index" to feed it to the assistant.
  4. Tutor LMS → Courses: create a course and a quiz.
  5. Open the site, sign in as a student and ask the assistant a question.

EOF
