# Setup guide

Two paths. Pick one — you do not need both.

---

## Path A — Docker (recommended for development)

Everything runs in containers, so nothing is installed on Windows except Docker
itself. This is the fastest way to see the site working.

### 1. Install Docker Desktop

<https://www.docker.com/products/docker-desktop/> — install, launch it, wait for
the whale icon to go green.

### 2. Configure

Open a terminal in `D:\chatbot`:

```powershell
copy .env.example .env
notepad .env
```

Set at minimum:

```ini
ADMIN_PASSWORD=something-strong
ADMIN_EMAIL=you@example.com
ANTHROPIC_API_KEY=sk-ant-...
```

Get the API key from <https://console.anthropic.com/settings/keys>.
Add about $5 of credit — that is enough for weeks of testing.

### 3. Start

```powershell
docker compose up -d
```

Wait ~30 seconds for the database to become healthy, then bootstrap the site:

```powershell
docker compose --profile tools run --rm cli bash /scripts/setup.sh
```

That installs WordPress, the plugin stack, activates the theme and creates the
Library / My Progress / Study Assistant pages with the menu wired up.

### 4. Open it

- Site: <http://localhost:8080>
- Admin: <http://localhost:8080/wp-admin>
- Database browser: <http://localhost:8081> (run with `--profile tools`)

### Everyday commands

```powershell
docker compose up -d          # start
docker compose down           # stop, keep the database
docker compose down -v        # stop and wipe the database (fresh start)
docker compose logs -f wordpress
docker compose --profile tools run --rm cli wp plugin list --allow-root
```

Your theme and plugin files are bind-mounted from `wp-content/`, so any edit
you save on disk is live on the next page refresh. No rebuild needed.

---

## Path B — LocalWP (no Docker)

If Docker is too heavy, [LocalWP](https://localwp.com/) is a one-click
WordPress installer for Windows.

1. Install LocalWP, create a site called **scholaris** (PHP 8.2+, MySQL 8).
2. Click **Go to site folder** → open `app/public/wp-content/`.
3. Copy `D:\chatbot\wp-content\themes\scholaris` into `themes/`.
4. Copy both folders from `D:\chatbot\wp-content\plugins\` into `plugins/`.
5. In wp-admin: Appearance → Themes → activate **Scholaris**.
6. Plugins → add **Tutor LMS**, activate it and the two Scholaris plugins.
7. Create the pages listed under *Pages the site expects* below.

---

## First-run checklist

Work through this once, in order.

### 1. Add the Claude API key

**Preferred** — edit `wp-config.php` and add this above the
`/* That's all, stop editing! */` line:

```php
define( 'EDUAI_ANTHROPIC_API_KEY', 'sk-ant-your-key-here' );
```

This keeps the key out of the database and out of any database export.

**Or** paste it into Settings → EduAI Assistant. Fine for development.

Then click **Test API connection** on that settings page. You want
"Connected to the Claude API successfully."

### 2. Upload your first study material

Library → Add study material:

- Title: the lecture name
- Excerpt: one or two sentences — this shows on the library card
- **Document** box on the right: Choose file → upload the PDF
- Subject and Material type on the right
- Publish

The page count fills in automatically for PDFs.

### 3. Index it for the assistant

Settings → EduAI Assistant → **Rebuild index**.

You should see something like *"Index rebuilt: 47 passages from 3 documents."*
If it says 0 passages from a PDF you just uploaded, the PDF is a scan with no
text layer — see *Troubleshooting* below.

From now on, indexing happens automatically whenever you save a document. The
manual rebuild is only for the initial import or after a bulk upload.

### 4. Create a course and a quiz

Tutor LMS → Courses → Add New. Inside the course builder:

- Add a topic, then a lesson
- Add a quiz to the topic
- Add questions — multiple choice, true/false, fill in the blanks, etc.
- Quiz settings: set **Passing grade** (the dashboard reads this to decide
  pass/fail), and set **Attempts allowed** to 0 for unlimited practice

### 5. Test as a student

Open a private browser window, register a new account, take the quiz, then
visit **/dashboard/**. You should see the attempt with its score, the pass/fail
badge and the trend chart.

Then click the assistant button and ask something answerable only from your
uploaded PDF. The answer should cite the document by name.

---

## Pages the site expects

`scripts/setup.sh` creates these. If you set the site up by hand, create them
with exactly these slugs and contents:

| Page | Slug | Content |
|---|---|---|
| Home | `home` | anything — the theme's `front-page.php` takes over |
| Library | `library` | `[scholaris_library per_page="12" filters="yes"]` |
| My Progress | `dashboard` | `[scholaris_dashboard]` |
| Study Assistant | `assistant` | `[eduai_panel height="600"]` |
| Summarise a Lecture | `summarise` | `[eduai_summarizer]` |

Then Settings → Reading → *Your homepage displays* → **A static page** → Home.

---

## All shortcodes

| Shortcode | What it renders |
|---|---|
| `[eduai_panel height="520"]` | Inline chat + summariser panel |
| `[eduai_summarizer]` | Just the lecture summariser |
| `[scholaris_library subject="" type="" per_page="12" filters="yes" columns="3"]` | Filterable material grid |
| `[scholaris_quiz_history limit="10" show_chart="yes" show_stats="yes"]` | Attempts table, stats and trend |
| `[scholaris_dashboard]` | Greeting, quiz history and recent material |

Any button on any page can open the assistant — give it `data-eduai-open`, or
`data-eduai-open="summary"` to land on the summariser tab:

```html
<button data-eduai-open>Ask the assistant</button>
```

---

## Troubleshooting

**"Index rebuilt: 0 passages"**
The PDF has no text layer (it is a photo of pages). Two options: run it through
OCR first (Adobe Acrobat, or `ocrmypdf` on the command line), or leave it — the
summariser still handles scans by sending the file to Claude directly, it is
only the searchable index that needs real text.

**Assistant replies "no course material matched"**
Either the index is empty (rebuild it) or the question uses words that appear
nowhere in your documents. MySQL FULLTEXT also ignores words under 4 characters
and words appearing in more than 50% of rows — normal for a small corpus, and it
resolves itself as you add more documents.

**"The Claude API rejected the key"**
The key is wrong, revoked, or the account has no credit. Check
<https://console.anthropic.com/settings/billing>.

**The microphone button does nothing**
Speech recognition needs Chrome or Edge, and an **HTTPS** connection.
`localhost` counts as secure; a plain-HTTP staging domain does not.

**Uploads fail on a big PDF**
Raise `upload_max_filesize` and `post_max_size` in PHP. In Docker they are
already 64 MB via `php/uploads.ini`. On shared hosting, use the host's PHP
settings panel.

**Quiz history is empty but you took a quiz**
Only *finished* attempts are shown. An abandoned attempt stays in the
`attempt_started` state and is filtered out by design.
